The files in this folder are import from the CC65 master branch
at https://github.com/cc65/cc65/blob/master/libsrc and have been
adapted to be in MADS syntax. The copyright is with the original
authors.
