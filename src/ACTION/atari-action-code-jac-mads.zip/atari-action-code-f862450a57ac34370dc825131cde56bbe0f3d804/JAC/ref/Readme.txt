
This archive contains the builds of the Action! programming language for Atari 8-bit computers.
See http://atari-action.sourceforge.net for more information.
See http://www.noniandjim.com/Jim/atari/ACTION_Reference_Manual-Def_Ed.pdf for the original English manual.
See http://wiki.strotmann.de/wiki/Wiki.jsp?page=ACTION%20Handbuch for revised the German manual.

* ROM Versions
  ============

* ACTION-36-ROM-OSS.car
  This is the original ROM version 3.6 by OSS.
  The file is type 15 OSS one chip 16 KB cartridge that can be used directly in emulators
  and in multi ROM emulation cartridges like The!Cart which support this type of bank switching
  cartridge directly. 

* ACTION-37-ROM-OSS-16k.car
  This is the latest build of the original ROM version 3.6 by OSS.
  It is 100% identical to the original version and only used to verify the correctness of the build.
  The file is type 15 OSS one chip 16 KB cartridge that can be used directly in emulators
  and in multi ROM emulation cartridges like The!Cart which support this type of bank switching
  cartridge directly.

* ACTION-37-ROM-Plain-16k.car
  This is the latest build of the ROM version 3.7P by JAC!.
  The file is type 2 standard 16 KB cartridge that can be used directly in emulators,
  in a standard 16k cartridge  without bank switching logic, and in multi ROM emulation cartridges
  like The!Cart which support this type of standard cartridge directly.


* Disk Versions
  =============
  The disk images contain DOS, the Action! "SYSALL.ACT" library and all related files.
  

* ACTION-37-DOS25.atr
  This is the latest build of the executable version 3.7X by JAC! on a single density DOS 2.5 disk.

* ACTION-37-MYDOS.atr
  This is the latest build of the executable version 3.7X by JAC! on a single density MyDOS 4.53/4 disk.
 
* ACTION-37-SDX.atr
  This is the latest build of the executable version 3.7X by JAC! on a single density SpartDOS disk.

* Features and Fixes
  ==================
  The 3.7P 16k ROM version contains the following features and fixes.
  * Allocate 16 pages of by default. This corresponds to SET $496=16 in the source code.
  
  The 3.7X executable version of Action! contains these additional features and fixes.
  * 


